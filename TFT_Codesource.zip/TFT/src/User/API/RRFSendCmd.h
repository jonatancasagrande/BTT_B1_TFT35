#ifndef _RRF_SEND_CMD_H_
#define _RRF_SEND_CMD_H_

#ifdef __cplusplus
extern "C" {
#endif

void rrfSendCmd(const char* cmd_ptr);

#ifdef __cplusplus
}
#endif

#endif
