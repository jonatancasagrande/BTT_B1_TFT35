#ifndef _LED_EVENT_H_
#define _LED_EVENT_H_

#ifdef __cplusplus
extern "C" {
#endif

void LED_CheckEvent(void);

#ifdef __cplusplus
}
#endif

#endif
